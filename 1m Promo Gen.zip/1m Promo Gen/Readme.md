# 🔥 Ultimate SteelSeries GG Account Creator & Promo Fetcher 🔥

## 📜 Introduction

Welcome to the Ultimate SteelSeries GG Account Creator & Promo Fetcher! This script automates the creation of SteelSeries GG accounts and retrieves promo codes using a seamless process. Whether you're a developer, gamer, or just hunting for promos, this tool is here to help!

> ⚠️ **Disclaimer:**  
> I'm not responsible for any misuse of this tool. Use it at your own risk and ensure compliance with SteelSeries' [Terms of Service](https://steelseries.com/terms-of-service).

## 🚀 Features

- **Automated Account Creation:** Easily generate new SteelSeries GG accounts.
- **Promo Code Retrieval:** Fetch promo codes for your created accounts.
- **Captcha Handling:** Pauses for manual captcha solving.
- **Thread-Safe Logging:** Clean and colored logging for easy debugging.
- **Auto-Restart SteelSeries GG:** Automatically restarts SteelSeries GG client during the process.

## 📁 File Structure

Ultimate-SteelSeries-Creator/
│
│   
├── ultimate.py                 # The main script to run the automation.
├── README.md               # You're here!
├── promos.txt          # Stores retrieved promo codes.
└── requirements.txt        # Python dependencies.


## 🛠️ Installation & Usage

### 1. Prerequisites

- Python 3.x installed on your system.
- SteelSeries GG client installed.

### 2. Installation

1. Install Dependencies  
   Run the following command to install the required Python libraries:
   ```sh
   pip install -r requirements.txt
   ```

2. Run the Script  
   python ultimate.py


### 3. Post-Execution

- **Accounts:** Check `data/accounts.txt` for accounts that were successfully created.
- **Promos:** Check `data/promos.txt` for retrieved promo codes.

## 💼 Disclaimer

This tool is intended for educational and testing purposes only. Misuse of this tool may result in violation of SteelSeries' Terms of Service, leading to account bans or other actions. Use responsibly!

## 📧 Contact

If you have any questions, suggestions, or just want to chat, feel free to reach out to me on Discord: termwave_.

Happy Automating! 🚀

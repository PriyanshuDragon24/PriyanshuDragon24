import requests
import re
import tls_client
import warnings
import os
import webbrowser
from mailtm import Email
from urllib3.exceptions import InsecureRequestWarning
import time
from itertools import cycle
import subprocess
import win32con
from colorama import Fore, Style, init

warnings.simplefilter('ignore', InsecureRequestWarning)
init(autoreset=True)

client = tls_client.Session(
    client_identifier='chrome_120',
    random_tls_extension_order=True
)

init(autoreset=True)

def banner():
    author = "ZEOM"
    ultimate = """ 
  _____ _     ___ _____ _____   _   _ _   _ ____  
 | ____| |   |_ _|_   _| ____| | | | | | | | __ ) 
 |  _| | |    | |  | | |  _|   | |_| | | | |  _ \ 
 | |___| |___ | |  | | | |___  |  _  | |_| | |_) |
 |_____|_____|___| |_| |_____| |_| |_|\___/|____/          
                                                                """   
    made_by = f"[ Made By {author} ]"
    console_width = os.get_terminal_size().columns
    ultimate_lines = ultimate.splitlines()
    centered_ultimate = "\n".join(line.center(console_width) for line in ultimate_lines)
    centered_made_by = made_by.center(console_width)
    print(f"{Fore.RED}{Style.BRIGHT}{centered_ultimate}\n{centered_made_by}")

first_run = True  

def listener(message):
    global verification_url
    pattern = r'https://accounts\.steelseries\.com/verify\?token=\S+'
    urls = re.findall(pattern, message['text'])
    if urls:
        verification_url = urls[0]

def create_account(email_service):
    global first_run
    if first_run:
        time.sleep(5)  
        first_run = False  
    
    email_service.register()
    email = str(email_service.address)
    headers = {
        "Accept": "application/json, text/plain, */*",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "es",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) steelseries-gg-client/3.0.0 Chrome/110.0.5481.179 Electron/23.1.3 Safari/537.36"
    }
    payload = {
        "email": email,
        "password1": "ultimAte69",
        "password2": "ultimAte69",
        "acceptedPrivacyPolicy": True
    }
    print(f"{Fore.LIGHTYELLOW_EX}Generating Using : {email} ")
    try:
        r = requests.post("https://127.0.0.1:6327/user", verify=False, headers=headers, json=payload)
        r.raise_for_status()
        data = r.json()
        if 'user' in data:
            username = data["user"]["username"]
            print(f"{Fore.LIGHTGREEN_EX}Account created successfully with Email: {email}, Username: {username}")
            return email
        else:
            print(f"{Fore.RED}No 'user' key found in response.")
            
            
    except requests.exceptions.RequestException as e:
        print(f"{Fore.RED}Error creating user: {e}")
        
        
        return None
    except ValueError:
        print(f"{Fore.RED}Error parsing JSON response")
        
        
        return None

def verify_account(email_service, email):
    global verification_url
    verification_url = None
    email_service.start(listener)
    print(f"{Fore.LIGHTBLUE_EX}Waiting for verification email...")
    timeout = 30  
    start_time = time.time()
    while verification_url is None and time.time() - start_time < timeout:
        time.sleep(5)
    if verification_url:
        print(f"{Fore.LIGHTGREEN_EX}Verification URL: {verification_url}")
        webbrowser.open(verification_url)
        time.sleep(5)
        print(f"{Fore.LIGHTCYAN_EX}Verification complete. Fetching promo code...")
        payload = {
            "name": "giveaway_discord_jul01"
        }
        try:
            reques = requests.post("https://127.0.0.1:6327/promos/code", verify=False, json=payload)
            reques.raise_for_status()  
            req = reques.json()  
            promo_code_url = req.get("promocode", "")
            print(f"{Fore.LIGHTMAGENTA_EX}Promo: {promo_code_url}")
            with open("promos.txt", 'a') as f:  
                f.write(f"{promo_code_url}\n")
        except requests.exceptions.RequestException as e:
            print(f"{Fore.RED}Error fetching promo code: {e}") 
    else:
        print(f"{Fore.RED}No verification URL found within the timeout period.")

def restart_steelseries_gg():
    subprocess.run(['taskkill', '/f', '/IM', 'SteelSeriesGGClient.exe'], 
                   creationflags=subprocess.CREATE_NO_WINDOW)
    startupinfo = subprocess.STARTUPINFO()
    startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startupinfo.wShowWindow = win32con.SW_SHOWMINIMIZED  
    subprocess.Popen(['cmd', '/c', 'start', '""', '"C:\\Program Files\\SteelSeries\\GG\\SteelSeriesGGClient.exe"'], 
                     startupinfo=startupinfo)

if __name__ == '__main__':
    banner()
    email_service = Email()  
    while True:
        restart_steelseries_gg()
        time.sleep(1)
        email = create_account(email_service)
        if email:
            verify_account(email_service, email)
        else:
            print(f"{Fore.RED}Failed to create account, retrying...")
        time.sleep(1)
